(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b974705a._.js",
  "static/chunks/node_modules_4813dece._.js"
],
    source: "dynamic"
});
