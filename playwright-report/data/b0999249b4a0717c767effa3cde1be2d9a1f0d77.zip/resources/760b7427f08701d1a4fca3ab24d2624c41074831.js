(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8ebb6d4b._.css",
  "static/chunks/node_modules_@supabase_node-fetch_browser_2bebfc6e.js",
  "static/chunks/node_modules_45bd7a39._.js",
  "static/chunks/src_95b1e1c3._.js"
],
    source: "dynamic"
});
